"use client";

import { useCallback, useEffect, useMemo, useState } from "react";

import type { ManualSizingMode, ManualTradePrefs } from "@/lib/forward-ledger";
import { dashboardClientFetch, formatFetchError, readJsonResponse } from "@/lib/api-fetch";
import type { ForwardPosition, ForwardSide, ForwardState } from "@/lib/forward-state";
import { priceUsd, usd } from "@/lib/format";

const DEFAULT_PREFS: ManualTradePrefs = {
  account_equity_usd: 1000,
  risk_pct_per_trade: 1,
  default_leverage: 10,
  default_stop_usd: 500,
  default_target_usd: 1500,
  sizing_mode: "risk",
  symbol: "BTCUSDT",
};

function previewQty(prefs: ManualTradePrefs, entry: number, stop: number, qtyOverride: string, mode: ManualSizingMode) {
  const stopDist = Math.abs(entry - stop);
  if (stopDist <= 0 || entry <= 0) return null;
  const q = parseFloat(qtyOverride);
  if (Number.isFinite(q) && q > 0) return q;
  if (mode === "qty") return null;
  if (mode === "notional") {
    const notional = prefs.account_equity_usd * (prefs.default_leverage / 10);
    return notional / entry;
  }
  const riskUsd = (prefs.account_equity_usd * prefs.risk_pct_per_trade) / 100;
  return riskUsd / stopDist;
}

export function ManualTradePanel({
  state,
  onState,
  disabled,
  focusPositionId,
  apiKey,
  apiSecret,
}: {
  state: ForwardState | null;
  onState: (s: ForwardState) => void;
  disabled?: boolean;
  focusPositionId?: string | null;
  apiKey?: string;
  apiSecret?: string;
}) {
  const mark = state?.mark_price ?? 0;
  const [prefs, setPrefs] = useState<ManualTradePrefs>(DEFAULT_PREFS);
  const [prefsMsg, setPrefsMsg] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  const [side, setSide] = useState<ForwardSide>("long");
  const [entry, setEntry] = useState("");
  const [stop, setStop] = useState("");
  const [target, setTarget] = useState("");
  const [qty, setQty] = useState("");
  const [leverage, setLeverage] = useState("");
  const [riskPct, setRiskPct] = useState("");
  const [note, setNote] = useState("");
  const [useUsdStops, setUseUsdStops] = useState(true);
  const [sendToBybit, setSendToBybit] = useState(true);

  const [editId, setEditId] = useState<string | null>(null);
  const [editStop, setEditStop] = useState("");
  const [editTarget, setEditTarget] = useState("");
  const [editQty, setEditQty] = useState("");
  const [editLev, setEditLev] = useState("");

  const manualOpen = useMemo(
    () => (state?.positions ?? []).filter((p) => p.manual || p.strategy_id === "manual"),
    [state?.positions],
  );

  const loadPrefs = useCallback(async () => {
    try {
      const res = await dashboardClientFetch("/api/manual-trade");
      const body = await readJsonResponse<{ ok?: boolean; prefs?: ManualTradePrefs }>(res);
      if (body.prefs) {
        setPrefs(body.prefs);
        setSendToBybit(body.prefs.send_to_bybit_default !== false);
      }
    } catch {
      /* keep defaults */
    }
  }, []);

  useEffect(() => {
    void loadPrefs();
  }, [loadPrefs]);

  useEffect(() => {
    if (!mark || entry) return;
    setEntry(mark.toFixed(2));
  }, [mark, entry]);

  const post = async (payload: Record<string, unknown>) => {
    setErr("");
    setBusy(true);
    try {
      const res = await dashboardClientFetch("/api/manual-trade", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          mark_price: mark || undefined,
          apiKey: apiKey?.trim() || undefined,
          apiSecret: apiSecret?.trim() || undefined,
          send_to_bybit: sendToBybit,
          ...payload,
        }),
      });
      const body = await readJsonResponse<{ ok?: boolean; error?: string; state?: ForwardState; prefs?: ManualTradePrefs }>(
        res,
      );
      if (!body.ok) {
        setErr(body.error ?? "Request failed");
        return;
      }
      if (body.prefs) {
        setPrefs(body.prefs);
        setSendToBybit(body.prefs.send_to_bybit_default !== false);
      }
      if (body.state) onState(body.state);
    } catch (e) {
      setErr(formatFetchError(e, "/api/manual-trade"));
    } finally {
      setBusy(false);
    }
  };

  const savePrefs = () =>
    void post({
      action: "save_prefs",
      ...prefs,
      send_to_bybit_default: sendToBybit,
    }).then(() => setPrefsMsg("Risk settings saved."));

  const entryNum = parseFloat(entry) || mark;
  const stopDist = parseFloat(stop) || prefs.default_stop_usd;
  const targetDist = parseFloat(target) || prefs.default_target_usd;
  const stopNum = useUsdStops
    ? side === "long"
      ? entryNum - stopDist
      : entryNum + stopDist
    : parseFloat(stop) || entryNum - prefs.default_stop_usd;
  const targetNum = useUsdStops
    ? side === "long"
      ? entryNum + targetDist
      : entryNum - targetDist
    : parseFloat(target) || entryNum + prefs.default_target_usd;
  const preview = previewQty(prefs, entryNum, stopNum, qty, prefs.sizing_mode);

  const openTrade = () =>
    void post({
      action: "open",
      side,
      entry_price: entryNum,
      stop_price: useUsdStops ? undefined : stopNum,
      target_price: useUsdStops ? undefined : targetNum,
      stop_usd: useUsdStops ? parseFloat(stop) || prefs.default_stop_usd : undefined,
      target_usd: useUsdStops ? parseFloat(target) || prefs.default_target_usd : undefined,
      qty: qty ? parseFloat(qty) : undefined,
      leverage: leverage ? parseFloat(leverage) : prefs.default_leverage,
      risk_pct: riskPct ? parseFloat(riskPct) : prefs.risk_pct_per_trade,
      reason: note,
    });

  const beginEdit = (p: ForwardPosition) => {
    setEditId(p.id);
    setEditStop(String(p.stop_price));
    setEditTarget(String(p.target_price));
    setEditQty(String(p.qty));
    setEditLev(String(p.leverage ?? prefs.default_leverage));
  };

  useEffect(() => {
    if (!focusPositionId || !state?.positions) return;
    const p = state.positions.find((x) => x.id === focusPositionId);
    if (p) beginEdit(p);
    // eslint-disable-next-line react-hooks/exhaustive-deps -- focus id only
  }, [focusPositionId, state?.positions]);

  const saveEdit = () => {
    if (!editId) return;
    void post({
      action: "update",
      position_id: editId,
      stop_price: parseFloat(editStop),
      target_price: parseFloat(editTarget),
      qty: parseFloat(editQty),
      leverage: parseFloat(editLev),
    }).then(() => setEditId(null));
  };

  const closePos = (id: string) => void post({ action: "close", position_id: id });

  const inputClass =
    "w-full rounded-lg border border-zinc-700 bg-zinc-950/80 px-3 py-2 text-sm text-zinc-100 placeholder:text-zinc-600";

  return (
    <div className="space-y-5">
      <section className="rounded-xl border border-violet-500/25 bg-violet-500/5 p-4">
        <h3 className="text-sm font-semibold text-violet-100">Risk management (defaults)</h3>
        <p className="mt-1 text-xs text-zinc-500">
          Paper book only — size from account equity and risk %. Saved in <code className="text-zinc-400">out/forward/manual_prefs.json</code>.
        </p>
        <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          <label className="block text-xs text-zinc-400">
            Account equity (USDT)
            <input
              type="number"
              className={`mt-1 ${inputClass}`}
              value={prefs.account_equity_usd}
              onChange={(e) => setPrefs((p) => ({ ...p, account_equity_usd: parseFloat(e.target.value) || 0 }))}
            />
          </label>
          <label className="block text-xs text-zinc-400">
            Risk per trade (%)
            <input
              type="number"
              step="0.1"
              className={`mt-1 ${inputClass}`}
              value={prefs.risk_pct_per_trade}
              onChange={(e) => setPrefs((p) => ({ ...p, risk_pct_per_trade: parseFloat(e.target.value) || 0 }))}
            />
          </label>
          <label className="block text-xs text-zinc-400">
            Default leverage
            <input
              type="number"
              className={`mt-1 ${inputClass}`}
              value={prefs.default_leverage}
              onChange={(e) => setPrefs((p) => ({ ...p, default_leverage: parseFloat(e.target.value) || 1 }))}
            />
          </label>
          <label className="block text-xs text-zinc-400">
            Default stop (USD)
            <input
              type="number"
              className={`mt-1 ${inputClass}`}
              value={prefs.default_stop_usd}
              onChange={(e) => setPrefs((p) => ({ ...p, default_stop_usd: parseFloat(e.target.value) || 0 }))}
            />
          </label>
          <label className="block text-xs text-zinc-400">
            Default target (USD)
            <input
              type="number"
              className={`mt-1 ${inputClass}`}
              value={prefs.default_target_usd}
              onChange={(e) => setPrefs((p) => ({ ...p, default_target_usd: parseFloat(e.target.value) || 0 }))}
            />
          </label>
          <label className="block text-xs text-zinc-400">
            Position sizing
            <select
              className={`mt-1 ${inputClass}`}
              value={prefs.sizing_mode}
              onChange={(e) => setPrefs((p) => ({ ...p, sizing_mode: e.target.value as ManualSizingMode }))}
            >
              <option value="risk">Risk % → qty from stop distance</option>
              <option value="qty">Fixed BTC qty (you type qty)</option>
              <option value="notional">Notional from equity × leverage/10</option>
            </select>
          </label>
        </div>
        <button
          type="button"
          disabled={disabled || busy}
          onClick={savePrefs}
          className="mt-4 rounded-lg bg-violet-600 px-4 py-2 text-sm font-medium text-white hover:bg-violet-500 disabled:opacity-40"
        >
          Save risk settings
        </button>
        {prefsMsg ? <p className="mt-2 text-xs text-emerald-300">{prefsMsg}</p> : null}
      </section>

      <label className="flex cursor-pointer items-center gap-2 rounded-lg border border-sky-500/30 bg-sky-500/10 px-3 py-2 text-xs text-sky-100">
        <input
          type="checkbox"
          checked={sendToBybit}
          onChange={(e) => setSendToBybit(e.target.checked)}
          className="h-4 w-4"
        />
        Send orders to Bybit demo (needs API keys above — market entry + SL/TP)
      </label>

      <section className="rounded-xl border border-zinc-800 bg-zinc-950/50 p-4">
        <h3 className="text-sm font-semibold text-zinc-100">Open manual trade</h3>
        <p className="mt-1 text-xs text-zinc-500">
          {mark ? `Mark ${priceUsd(mark)} · ` : ""}
          Est. qty {preview != null ? preview.toFixed(6) : "—"} BTC
          {preview != null && entryNum ? ` · notional ~${usd(entryNum * preview)}` : ""}
        </p>
        <div className="mt-3 flex flex-wrap gap-2">
          {(["long", "short"] as const).map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => setSide(s)}
              className={`rounded-lg px-3 py-1.5 text-xs font-semibold uppercase ${
                side === s
                  ? s === "long"
                    ? "bg-emerald-600 text-white"
                    : "bg-rose-600 text-white"
                  : "border border-zinc-700 text-zinc-400"
              }`}
            >
              {s}
            </button>
          ))}
        </div>
        <div className="mt-3 grid gap-3 sm:grid-cols-2">
          <label className="text-xs text-zinc-400">
            Entry
            <input type="number" className={`mt-1 ${inputClass}`} value={entry} onChange={(e) => setEntry(e.target.value)} />
          </label>
          <label className="text-xs text-zinc-400">
            Leverage (this trade)
            <input
              type="number"
              className={`mt-1 ${inputClass}`}
              placeholder={String(prefs.default_leverage)}
              value={leverage}
              onChange={(e) => setLeverage(e.target.value)}
            />
          </label>
          <label className="text-xs text-zinc-400">
            <span className="flex items-center gap-2">
              Stop {useUsdStops ? "(USDT distance per BTC)" : "(price)"}
              <button type="button" className="text-violet-300 underline" onClick={() => setUseUsdStops((v) => !v)}>
                switch
              </button>
            </span>
            <input
              type="number"
              className={`mt-1 ${inputClass}`}
              placeholder={useUsdStops ? String(prefs.default_stop_usd) : stopNum.toFixed(2)}
              value={stop}
              onChange={(e) => setStop(e.target.value)}
            />
          </label>
          <label className="text-xs text-zinc-400">
            Target {useUsdStops ? "(USDT distance per BTC)" : "(price)"}
            <input
              type="number"
              className={`mt-1 ${inputClass}`}
              placeholder={useUsdStops ? String(prefs.default_target_usd) : targetNum.toFixed(2)}
              value={target}
              onChange={(e) => setTarget(e.target.value)}
            />
          </label>
          <label className="text-xs text-zinc-400">
            Risk % (override)
            <input
              type="number"
              step="0.1"
              className={`mt-1 ${inputClass}`}
              placeholder={String(prefs.risk_pct_per_trade)}
              value={riskPct}
              onChange={(e) => setRiskPct(e.target.value)}
            />
          </label>
          <label className="text-xs text-zinc-400">
            BTC qty (optional override)
            <input type="number" step="0.000001" className={`mt-1 ${inputClass}`} value={qty} onChange={(e) => setQty(e.target.value)} />
          </label>
        </div>
        <label className="mt-3 block text-xs text-zinc-400">
          Note
          <input type="text" className={`mt-1 ${inputClass}`} value={note} onChange={(e) => setNote(e.target.value)} />
        </label>
        <button
          type="button"
          disabled={disabled || busy}
          onClick={openTrade}
          className="mt-4 rounded-lg bg-emerald-600 px-4 py-2 text-sm font-medium text-white hover:bg-emerald-500 disabled:opacity-40"
        >
          Add paper position
        </button>
      </section>

      {manualOpen.length > 0 ? (
        <section className="rounded-xl border border-zinc-800 bg-zinc-900/40 p-4">
          <h3 className="text-sm font-semibold text-zinc-100">Edit or close manual positions</h3>
          <ul className="mt-3 space-y-3">
            {manualOpen.map((p) => (
              <li key={p.id} className="rounded-lg border border-zinc-800 bg-zinc-950/60 p-3 text-sm">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="font-medium uppercase text-zinc-300">{p.side}</span>
                  <span className="tabular-nums text-zinc-400">
                    {p.qty} BTC · {p.leverage ?? 1}x · risk {p.risk_pct ?? "—"}%
                  </span>
                </div>
                <p className="mt-1 tabular-nums text-zinc-200">
                  Entry {priceUsd(p.entry_price)} · SL {priceUsd(p.stop_price)} · TP {priceUsd(p.target_price)}
                </p>
                {editId === p.id ? (
                  <div className="mt-3 grid gap-2 sm:grid-cols-2">
                    <input className={inputClass} value={editStop} onChange={(e) => setEditStop(e.target.value)} placeholder="Stop price" />
                    <input className={inputClass} value={editTarget} onChange={(e) => setEditTarget(e.target.value)} placeholder="Target price" />
                    <input className={inputClass} value={editQty} onChange={(e) => setEditQty(e.target.value)} placeholder="Qty" />
                    <input className={inputClass} value={editLev} onChange={(e) => setEditLev(e.target.value)} placeholder="Leverage" />
                    <button type="button" className="rounded-lg bg-violet-600 px-3 py-2 text-xs text-white" onClick={saveEdit}>
                      Save changes
                    </button>
                    <button type="button" className="rounded-lg border border-zinc-600 px-3 py-2 text-xs" onClick={() => setEditId(null)}>
                      Cancel
                    </button>
                  </div>
                ) : (
                  <div className="mt-3 flex flex-wrap gap-2">
                    <button type="button" className="rounded-lg border border-zinc-600 px-3 py-1.5 text-xs hover:bg-zinc-800" onClick={() => beginEdit(p)}>
                      Edit SL / TP / size
                    </button>
                    <button
                      type="button"
                      className="rounded-lg border border-rose-500/50 px-3 py-1.5 text-xs text-rose-200 hover:bg-rose-500/10"
                      onClick={() => closePos(p.id)}
                    >
                      Close at mark
                    </button>
                  </div>
                )}
              </li>
            ))}
          </ul>
        </section>
      ) : null}

      {err ? (
        <p className="rounded-lg border border-rose-500/40 bg-rose-500/10 px-3 py-2 text-sm text-rose-100">{err}</p>
      ) : null}
      {disabled ? (
        <p className="text-xs text-amber-200/90">Run the dashboard locally (START-HERE-43123.bat) to save manual trades to the paper ledger.</p>
      ) : null}
    </div>
  );
}
