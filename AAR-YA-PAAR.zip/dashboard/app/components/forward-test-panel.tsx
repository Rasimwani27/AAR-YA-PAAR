"use client";

import { useCallback, useEffect, useState } from "react";

import { TradingDesk } from "@/app/components/trading-desk";
import { FORWARD_STRATEGIES, type ForwardStrategyId } from "@/lib/forward-config";
import {
  dashboardClientFetch,
  formatFetchError,
  isLocalDashboard,
  pingSameOrigin,
  readJsonResponse,
} from "@/lib/api-fetch";
import { LAB_BUILD } from "@/lib/lab-version";
import type { ForwardState } from "@/lib/forward-state";

type ProbeResult = {
  ok?: boolean;
  testnet?: boolean;
  canTrade?: boolean;
  totalWalletBalance?: string;
  availableBalance?: string;
};

export function ForwardTestPanel({
  canRun,
  execBlocked,
  healthLoading,
}: {
  canRun: boolean;
  execBlocked: boolean;
  healthLoading: boolean;
}) {
  const [forwardExchange, setForwardExchange] = useState<"binance" | "bybit">("bybit");
  const [apiKey, setApiKey] = useState("");
  const [apiSecret, setApiSecret] = useState("");
  const [selected, setSelected] = useState<ForwardStrategyId[]>(["fade-reversal", "london-mid-engulf"]);
  const [probe, setProbe] = useState<ProbeResult | null>(null);
  const [statusMsg, setStatusMsg] = useState("");
  const [probeError, setProbeError] = useState("");
  const [probeLoading, setProbeLoading] = useState(false);
  const [jobStatus, setJobStatus] = useState<string>("");
  const [jobError, setJobError] = useState<string>("");
  const [forwardState, setForwardState] = useState<ForwardState | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [lastClick, setLastClick] = useState("");

  const buttonsDisabled = probeLoading;

  useEffect(() => {
    if (!probeLoading) return;
    const timer = window.setTimeout(() => setProbeLoading(false), 22_000);
    return () => window.clearTimeout(timer);
  }, [probeLoading]);

  const toggleStrategy = (id: ForwardStrategyId) => {
    setSelected((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  };

  const testDashboardOnly = useCallback(async () => {
    setLastClick("dashboard");
    setProbeError("");
    setStatusMsg("");
    setProbe(null);
    setProbeLoading(true);
    try {
      const pingOk = await pingSameOrigin();
      if (!pingOk) {
        setProbeError("Dashboard API offline. Run START-HERE-43123.bat from the repo folder and keep that window open.");
        return;
      }
      const res = await dashboardClientFetch("/api/health");
      const body = await readJsonResponse<Record<string, unknown>>(res);
      if (body.hosted || body.disableExec) {
        setStatusMsg(
          `Dashboard online (${LAB_BUILD}) · Bybit/Binance API test works here when exposed. Python forward test: run START-HERE-43123.bat on your PC.`,
        );
        return;
      }
      if (body.engineError) {
        setProbeError(String(body.engineError));
        return;
      }
      setStatusMsg(`Engine OK · repo: ${body.repoRoot ?? "?"} · forward test: ${String(body.forwardTest)}`);
    } catch (e) {
      setProbeError(formatFetchError(e, "/api/health"));
    } finally {
      setProbeLoading(false);
    }
  }, []);

  const refreshLiveOnline = useCallback(async () => {
    if (!apiKey.trim() || !apiSecret.trim()) return;
    const path = forwardExchange === "bybit" ? "/api/bybit/live" : "/api/binance/live";
    try {
      const res = await dashboardClientFetch(path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ apiKey: apiKey.trim(), apiSecret: apiSecret.trim() }),
      });
      const body = await res.json();
      if (body.ok && body.exchange_positions) {
        setForwardState((prev) => ({
          ...prev,
          ok: true,
          updated_at: body.updated_at,
          exchange: forwardExchange,
          exchange_positions: body.exchange_positions,
          exchange_stats: body.exchange_stats,
          probe: body.probe,
          stats: prev?.stats ?? undefined,
        }));
      }
    } catch {
      /* ignore */
    }
  }, [apiKey, apiSecret, forwardExchange]);

  const testConnection = useCallback(async () => {
    setLastClick("binance");
    setProbeError("");
    setStatusMsg("");
    setProbe(null);
    const key = apiKey.trim();
    const secret = apiSecret.trim();
    if (!key || !secret) {
      setProbeError("Enter both API key and secret first.");
      return;
    }
    setProbeLoading(true);
    try {
      const res = await dashboardClientFetch("/api/binance/test", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ apiKey: key, apiSecret: secret }),
      });
      const body = await res.json();
      if (!body.ok) {
        setProbeError(typeof body.error === "string" ? body.error : JSON.stringify(body.error));
        return;
      }
      setProbe(body.data as ProbeResult);
      setStatusMsg(
        body.mode === "online"
          ? "Binance testnet OK (online server — keys not saved). Start/Stop forward test still needs local 43123."
          : "Binance testnet connection successful.",
      );
      if (body.mode === "online") await refreshLiveOnline();
    } catch (e) {
      setProbeError(formatFetchError(e, "/api/binance/test"));
    } finally {
      setProbeLoading(false);
    }
  }, [apiKey, apiSecret, refreshLiveOnline]);

  const testBybit = useCallback(async () => {
    setLastClick("bybit");
    setProbeError("");
    setStatusMsg("");
    setProbe(null);
    const key = apiKey.trim();
    const secret = apiSecret.trim();
    if (!key || !secret) {
      setProbeError("Enter both API key and secret first.");
      return;
    }
    setProbeLoading(true);
    try {
      const res = await dashboardClientFetch(
        "/api/bybit/test",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ apiKey: key, apiSecret: secret }),
        },
        20_000,
      );
      const body = await res.json();
      if (!body.ok) {
        setProbeError(typeof body.error === "string" ? body.error : JSON.stringify(body.error));
        return;
      }
      setProbe(body.data as ProbeResult);
      setStatusMsg(
        "Bybit demo API OK. Forward test auto-places demo orders on signals (set AAR_BYBIT_AUTO_TRADE=0 to paper-only).",
      );
      if (body.mode === "online") await refreshLiveOnline();
    } catch (e) {
      setProbeError(formatFetchError(e, "/api/bybit/test"));
    } finally {
      setProbeLoading(false);
    }
  }, [apiKey, apiSecret, refreshLiveOnline]);

  const refreshState = useCallback(async () => {
    try {
      const res = await dashboardClientFetch("/api/forward-test");
      const body = await res.json();
      if (body.job?.status) setJobStatus(body.job.status);
      if (body.job?.error) setJobError(String(body.job.error));
      else if (body.job?.status !== "error") setJobError("");
      if (body.state) {
        setForwardState(body.state as ForwardState);
        const st = body.state as ForwardState & { error?: string };
        if (st.error && body.job?.status === "error") setJobError(st.error);
      }
    } catch {
      /* ignore */
    }
  }, []);

  useEffect(() => {
    const fast = jobStatus === "running";
    const ms = execBlocked ? 30_000 : fast ? 5_000 : 12_000;
    const t = setInterval(() => {
      if (execBlocked) void refreshLiveOnline();
      else void refreshState();
    }, ms);
    if (execBlocked) void refreshLiveOnline();
    else void refreshState();
    return () => clearInterval(t);
  }, [execBlocked, refreshState, refreshLiveOnline, jobStatus]);

  async function startForward() {
    setError("");
    setBusy(true);
    try {
      const res = await dashboardClientFetch("/api/forward-test", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "start",
          forwardExchange,
          apiKey: apiKey.trim(),
          apiSecret: apiSecret.trim(),
          strategies: selected,
        }),
      });
      const body = await res.json();
      if (!body.ok) {
        setError(body.error ?? "Start failed");
        return;
      }
      setJobStatus(body.job?.status ?? "running");
      setJobError("");
      await refreshState();
    } catch (e) {
      setError(formatFetchError(e, "/api/forward-test"));
    } finally {
      setBusy(false);
    }
  }

  async function stopForward() {
    setBusy(true);
    try {
      await dashboardClientFetch("/api/forward-test", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "stop" }),
      });
      setJobStatus("stopped");
    } finally {
      setBusy(false);
    }
  }

  async function runSingleTick() {
    setError("");
    setBusy(true);
    try {
      const res = await dashboardClientFetch("/api/forward-test", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "tick",
          forwardExchange,
          apiKey: apiKey.trim(),
          apiSecret: apiSecret.trim(),
          strategies: selected,
        }),
      });
      const body = await res.json();
      if (!body.ok) {
        setError(body.error ?? "Tick failed");
        return;
      }
      setForwardState(body.data as ForwardState);
    } catch (e) {
      setError(formatFetchError(e, "/api/forward-test"));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="relative z-10 space-y-8" style={{ pointerEvents: "auto" }}>
      {healthLoading ? (
        <p className="text-sm text-zinc-400">
          Checking engine… test buttons below still work (or wait up to 12s for the status pill).
        </p>
      ) : null}
      <section className="rounded-2xl border border-zinc-800/80 bg-zinc-900/50 p-5 shadow-xl ring-1 ring-white/5">
        <h2 className="text-sm font-semibold text-zinc-200">Connection &amp; credentials</h2>
        <p className="text-[10px] text-zinc-600">Build {LAB_BUILD}</p>
        <div className="mt-2 flex flex-wrap gap-4 text-sm text-zinc-400">
          <label className="inline-flex cursor-pointer items-center gap-2">
            <input
              type="radio"
              name="forwardExchange"
              checked={forwardExchange === "bybit"}
              onChange={() => setForwardExchange("bybit")}
            />
            Bybit demo (Hyro path)
          </label>
          <label className="inline-flex cursor-pointer items-center gap-2">
            <input
              type="radio"
              name="forwardExchange"
              checked={forwardExchange === "binance"}
              onChange={() => setForwardExchange("binance")}
            />
            Binance futures testnet (legacy)
          </label>
        </div>
        <p className="mt-1 text-sm text-zinc-500">
          Keys are sent only to your local Python process (not saved).
          {forwardExchange === "bybit" ? (
            <>
              {" "}
              Create keys in{" "}
              <a className="text-amber-400 underline" href="https://www.bybit.com/" target="_blank" rel="noreferrer">
                Bybit
              </a>{" "}
              → switch to <strong className="text-zinc-300">Demo Trading</strong> → API ({' '}
              <a
                className="text-amber-400 underline"
                href="https://bybit-exchange.github.io/docs/v5/demo"
                target="_blank"
                rel="noreferrer"
              >
                docs
              </a>
              ).
            </>
          ) : (
            <>
              {" "}
              Get keys from{" "}
              <a className="text-amber-400 underline" href="https://testnet.binancefuture.com/" target="_blank" rel="noreferrer">
                testnet.binancefuture.com
              </a>
              .
            </>
          )}
        </p>

        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          <label className="block text-xs text-zinc-400">
            API key
            <input
              type="text"
              autoComplete="off"
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              placeholder={forwardExchange === "bybit" ? "Bybit demo API key" : "Binance testnet API key"}
              className="mt-1 w-full rounded-lg border border-zinc-700 bg-zinc-950 px-3 py-2 text-sm text-zinc-100"
            />
          </label>
          <label className="block text-xs text-zinc-400">
            Secret key
            <input
              type="password"
              autoComplete="new-password"
              value={apiSecret}
              onChange={(e) => setApiSecret(e.target.value)}
              placeholder={forwardExchange === "bybit" ? "Bybit demo secret" : "Binance testnet secret"}
              className="mt-1 w-full rounded-lg border border-zinc-700 bg-zinc-950 px-3 py-2 text-sm text-zinc-100"
            />
          </label>
        </div>

        <div className="mt-4 flex flex-wrap gap-2">
          <button
            type="button"
            disabled={buttonsDisabled}
            onClick={(e) => {
              e.preventDefault();
              void testDashboardOnly();
            }}
            className="relative z-20 cursor-pointer rounded-lg border-2 border-zinc-500 bg-zinc-800 px-4 py-2.5 text-sm font-semibold text-white hover:bg-zinc-700 disabled:cursor-not-allowed disabled:opacity-40"
          >
            {probeLoading && lastClick === "dashboard" ? "Testing…" : "1. Test dashboard connection"}
          </button>
          <button
            type="button"
            disabled={buttonsDisabled || forwardExchange !== "binance"}
            onClick={(e) => {
              e.preventDefault();
              void testConnection();
            }}
            className="relative z-20 cursor-pointer rounded-lg border-2 border-amber-500 bg-amber-600 px-4 py-2.5 text-sm font-semibold text-zinc-950 hover:bg-amber-500 disabled:cursor-not-allowed disabled:opacity-40"
          >
            {probeLoading && lastClick === "binance" ? "Testing…" : "2. Test Binance testnet API"}
          </button>
          <button
            type="button"
            disabled={buttonsDisabled || forwardExchange !== "bybit"}
            onClick={(e) => {
              e.preventDefault();
              void testBybit();
            }}
            className="relative z-20 cursor-pointer rounded-lg border-2 border-sky-500 bg-sky-600 px-4 py-2.5 text-sm font-semibold text-zinc-950 hover:bg-sky-500 disabled:cursor-not-allowed disabled:opacity-40"
          >
            {probeLoading && lastClick === "bybit" ? "Testing…" : "2. Test Bybit demo API"}
          </button>
          <a
            href="/api/ping"
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center rounded-lg border border-zinc-600 px-4 py-2.5 text-sm text-zinc-300 hover:bg-zinc-800"
          >
            Open /api/ping
          </a>
        </div>

        {statusMsg ? (
          <p className="mt-3 rounded-lg border border-emerald-500/40 bg-emerald-500/10 px-3 py-2 text-sm text-emerald-100">
            {statusMsg}
          </p>
        ) : null}
        {probeError ? (
          <p className="mt-3 rounded-lg border border-rose-500/40 bg-rose-500/10 px-3 py-2 text-sm text-rose-100 whitespace-pre-wrap">
            {probeError}
          </p>
        ) : null}
        {probe?.availableBalance !== undefined && probe?.availableBalance !== null ? (
          <p className="mt-3 text-sm text-emerald-200">
            {probe.totalWalletBalance != null ? `Wallet ${probe.totalWalletBalance} USDT · ` : null}
            available {probe.availableBalance} USDT
            {probe.canTrade !== undefined ? ` · canTrade ${String(probe.canTrade)}` : null}
          </p>
        ) : null}
      </section>

      <section className="rounded-2xl border border-zinc-800/80 bg-zinc-900/50 p-5 ring-1 ring-white/5">
        <h2 className="text-sm font-semibold text-zinc-200">Strategies &amp; engine</h2>
        <div className="mt-4 space-y-2">
          {FORWARD_STRATEGIES.map((s) => (
            <label
              key={s.id}
              className="flex cursor-pointer items-start gap-3 rounded-lg border border-zinc-700/80 bg-zinc-950/50 p-3"
            >
              <input
                type="checkbox"
                checked={selected.includes(s.id)}
                onChange={() => toggleStrategy(s.id)}
                className="mt-1 h-4 w-4"
              />
              <span>
                <span className="font-medium text-zinc-100">{s.label}</span>
                <span className="block text-xs text-zinc-500">{s.description}</span>
              </span>
            </label>
          ))}
        </div>
        <div className="mt-4 flex flex-wrap gap-2">
          <button
            type="button"
            disabled={!canRun || busy || execBlocked || selected.length === 0}
            onClick={() => void startForward()}
            className="cursor-pointer rounded-lg bg-emerald-600 px-4 py-2 text-sm font-medium text-white hover:bg-emerald-500 disabled:opacity-40"
          >
            Start forward test
          </button>
          <button
            type="button"
            disabled={busy || execBlocked}
            onClick={() => void stopForward()}
            className="cursor-pointer rounded-lg border border-zinc-600 px-4 py-2 text-sm hover:bg-zinc-800 disabled:opacity-40"
          >
            Stop
          </button>
          <button
            type="button"
            disabled={!canRun || busy || execBlocked}
            onClick={() => void runSingleTick()}
            className="cursor-pointer rounded-lg border border-amber-600/50 px-4 py-2 text-sm text-amber-200 hover:bg-amber-500/10 disabled:opacity-40"
          >
            Run one tick
          </button>
        </div>
        {jobStatus ? (
          <p className="mt-2 text-xs text-zinc-500">
            Job: {jobStatus}
            {jobError ? <span className="mt-1 block text-rose-400/90">{jobError}</span> : null}
          </p>
        ) : null}
      </section>

      <section className="rounded-2xl border border-zinc-700/60 bg-gradient-to-b from-zinc-900/80 to-zinc-950/90 p-5 shadow-2xl ring-1 ring-amber-500/10">
        <h2 className="text-base font-semibold text-zinc-100">Trading desk</h2>
        <p className="mt-1 text-xs text-zinc-500">
          Live paper positions, manual trades (risk %, leverage, SL/TP), exchange sync, and history (updates while forward test runs).
        </p>
        <div className="mt-5">
          <TradingDesk
            state={forwardState}
            jobStatus={jobStatus}
            onState={setForwardState}
            manualDisabled={execBlocked || !canRun}
            apiKey={apiKey}
            apiSecret={apiSecret}
          />
        </div>
      </section>

      {error ? (
        <div className="rounded-xl border border-rose-500/30 bg-rose-500/10 px-4 py-3 text-sm text-rose-100 whitespace-pre-wrap">
          {error}
        </div>
      ) : null}
    </div>
  );
}
