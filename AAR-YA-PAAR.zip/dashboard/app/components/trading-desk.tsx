"use client";

import { useState } from "react";

import { LivePositionsPanel } from "@/app/components/live-positions-panel";
import { ManualTradePanel } from "@/app/components/manual-trade-panel";
import { SessionTimerPanel } from "@/app/components/session-timer-panel";
import { MetricCard } from "@/app/components/metric-card";
import { StrategyStatusGrid } from "@/app/components/strategy-status-grid";
import { TradeHistoryPanel } from "@/app/components/trade-history-panel";
import { TradingViewPanel } from "@/app/components/tradingview-panel";
import { dashboardClientFetch, readJsonResponse } from "@/lib/api-fetch";
import type { ForwardPosition, ForwardState } from "@/lib/forward-state";
import { LAB_BUILD } from "@/lib/lab-version";
import { pct, priceUsd, usd } from "@/lib/format";
import { resolveForwardStats, sumExchangeUnrealized } from "@/lib/forward-stats";

type Tab = "overview" | "manual" | "positions" | "history" | "charts";

export function TradingDesk({
  state,
  jobStatus,
  onState,
  manualDisabled,
  apiKey,
  apiSecret,
}: {
  state: ForwardState | null;
  jobStatus: string;
  onState?: (s: ForwardState) => void;
  manualDisabled?: boolean;
  apiKey?: string;
  apiSecret?: string;
}) {
  const [tab, setTab] = useState<Tab>("overview");
  const [focusManualId, setFocusManualId] = useState<string | null>(null);
  const stats = resolveForwardStats(state);
  const positions = state?.positions ?? [];
  const history = state?.history ?? [];
  const exchange = state?.exchange_positions ?? [];
  const exchangeUpnl =
    state?.exchange_stats?.unrealized_usd ?? sumExchangeUnrealized(exchange);

  const manualClose = async (p: ForwardPosition) => {
    if (!onState) return;
    try {
      const res = await dashboardClientFetch("/api/manual-trade", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "close",
          position_id: p.id,
          mark_price: state?.mark_price,
          apiKey: apiKey?.trim() || undefined,
          apiSecret: apiSecret?.trim() || undefined,
          send_to_bybit: p.bybit_live,
        }),
      });
      const body = await readJsonResponse<{ state?: ForwardState }>(res);
      if (body.state) onState(body.state);
    } catch {
      /* ignore */
    }
  };

  const tabs: { id: Tab; label: string }[] = [
    { id: "overview", label: "Overview" },
    { id: "manual", label: "Manual trade" },
    { id: "positions", label: `Positions (${positions.length})` },
    { id: "history", label: `History (${history.length})` },
    { id: "charts", label: "Charts · TV" },
  ];

  return (
    <div className="space-y-5">
      <SessionTimerPanel disabled={manualDisabled} />
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="inline-flex rounded-xl border border-zinc-800 bg-zinc-950/80 p-1">
          {tabs.map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setTab(t.id)}
              className={`rounded-lg px-3 py-1.5 text-xs font-medium transition-colors ${
                tab === t.id ? "bg-zinc-800 text-zinc-100" : "text-zinc-500 hover:text-zinc-300"
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
        <div className="flex flex-wrap items-center gap-2 text-xs text-zinc-500">
          {state?.exchange ? (
            <span className="rounded-full bg-sky-500/15 px-2 py-0.5 font-medium text-sky-300">
              {state.exchange === "bybit" ? "Bybit demo" : state.exchange}
            </span>
          ) : null}
          {state?.updated_at ? (
            <span>Updated {new Date(state.updated_at).toLocaleTimeString()}</span>
          ) : null}
          {jobStatus ? (
            <span className="rounded-full bg-zinc-800 px-2 py-0.5 capitalize text-zinc-400">Job {jobStatus}</span>
          ) : null}
          {state?.mark_price ? (
            <span className="rounded-full bg-amber-500/10 px-2 py-0.5 font-semibold text-amber-200">
              BTC {priceUsd(state.mark_price)}
            </span>
          ) : null}
          <span className="rounded-full bg-violet-500/10 px-2 py-0.5 text-violet-200" title="If this does not match, you are on an old folder or zip">
            Build {LAB_BUILD}
          </span>
        </div>
      </div>

      {stats ? (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
          <MetricCard
            label="Total P&amp;L (paper)"
            value={usd(stats.total_pnl_usd)}
            sub={`Realized ${usd(stats.realized_pnl_usd)} · Open ${usd(stats.unrealized_pnl_usd)}`}
            tone={stats.total_pnl_usd > 0 ? "profit" : stats.total_pnl_usd < 0 ? "loss" : "neutral"}
          />
          <MetricCard
            label="Bybit demo (live uPnL)"
            value={usd(exchangeUpnl)}
            sub={
              exchange.length
                ? `${exchange.length} exchange position(s) · not double-counted in paper`
                : "No open exchange positions"
            }
            tone={exchangeUpnl > 0 ? "profit" : exchangeUpnl < 0 ? "loss" : "neutral"}
          />
          <MetricCard
            label="Win rate"
            value={pct(stats.win_rate_pct, 1)}
            sub={`${stats.wins}W / ${stats.losses}L · ${stats.closed_trades} closed`}
            tone={stats.win_rate_pct >= 50 ? "profit" : "neutral"}
          />
          <MetricCard
            label="Open positions"
            value={String(stats.open_count)}
            sub="Strategies + manual paper"
          />
          <MetricCard
            label="Today (realized)"
            value={usd(stats.today_realized_usd)}
            tone={stats.today_realized_usd > 0 ? "profit" : stats.today_realized_usd < 0 ? "loss" : "neutral"}
          />
        </div>
      ) : null}
      {state?.bybit_errors?.length ? (
        <p className="text-xs text-amber-400/90" role="status">
          Bybit order notes: {state.bybit_errors.slice(-3).join(" · ")}
        </p>
      ) : null}

      {tab === "overview" ? (
        <>
          <StrategyStatusGrid results={state?.results ?? []} markPrice={state?.mark_price} />
          {stats?.by_strategy?.length ? (
            <div className="grid gap-2 sm:grid-cols-2">
              {stats.by_strategy.map((s) => (
                <div
                  key={s.strategy_id}
                  className="flex items-center justify-between rounded-lg border border-zinc-800/80 bg-zinc-950/50 px-3 py-2 text-sm"
                >
                  <span className="text-zinc-400">{s.strategy_name}</span>
                  <span className="tabular-nums text-zinc-200">
                    {s.trades} trades · {usd(s.net_usd)}
                  </span>
                </div>
              ))}
            </div>
          ) : null}
          <LivePositionsPanel
            paper={positions}
            exchange={exchange}
            markPrice={state?.mark_price}
            forwardExchange={state?.exchange}
            onEditManual={(p) => {
              setFocusManualId(p.id);
              setTab("manual");
            }}
            onCloseManual={(p) => void manualClose(p)}
          />
        </>
      ) : null}

      {tab === "manual" ? (
        <ManualTradePanel
          state={state}
          disabled={manualDisabled}
          focusPositionId={focusManualId}
          apiKey={apiKey}
          apiSecret={apiSecret}
          onState={(s) => {
            onState?.(s);
            setFocusManualId(null);
          }}
        />
      ) : null}

      {tab === "positions" ? (
        <LivePositionsPanel
          paper={positions}
          exchange={exchange}
          markPrice={state?.mark_price}
          forwardExchange={state?.exchange}
          onEditManual={(p) => {
            setFocusManualId(p.id);
            setTab("manual");
          }}
          onCloseManual={(p) => void manualClose(p)}
        />
      ) : null}

      {tab === "history" ? <TradeHistoryPanel history={history} /> : null}

      {tab === "charts" ? <TradingViewPanel history={history} positions={positions} /> : null}
    </div>
  );
}
