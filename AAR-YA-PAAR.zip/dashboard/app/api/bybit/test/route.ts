import { NextResponse } from "next/server";

import { probeBybitDemo } from "@/lib/bybit-probe";

export const runtime = "nodejs";

/** Bybit **demo trading** API probe (keys from Bybit → Demo Trading → API). Node-only — no Python required. */
export async function POST(req: Request) {
  let body: { apiKey?: string; apiSecret?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, error: "Invalid JSON" }, { status: 400 });
  }
  const apiKey = (body.apiKey ?? "").trim();
  const apiSecret = (body.apiSecret ?? "").trim();
  if (!apiKey || !apiSecret) {
    return NextResponse.json({ ok: false, error: "API key and secret required" }, { status: 400 });
  }

  try {
    const data = await probeBybitDemo(apiKey, apiSecret);
    return NextResponse.json({ ok: true, data, mode: "online" });
  } catch (e) {
    const msg = e instanceof Error ? e.message : "Bybit probe failed";
    return NextResponse.json({ ok: false, error: msg }, { status: 400 });
  }
}
