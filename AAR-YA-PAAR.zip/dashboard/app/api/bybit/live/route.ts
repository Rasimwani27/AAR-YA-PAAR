import { NextResponse } from "next/server";

import { fetchBybitPositions } from "@/lib/bybit-orders";
import { probeBybitDemo } from "@/lib/bybit-probe";

export const runtime = "nodejs";

export async function POST(req: Request) {
  let body: { apiKey?: string; apiSecret?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, error: "Invalid JSON" }, { status: 400 });
  }
  const apiKey = (body.apiKey ?? "").trim();
  const apiSecret = (body.apiSecret ?? "").trim();
  if (!apiKey || !apiSecret) {
    return NextResponse.json({ ok: false, error: "API key and secret required" }, { status: 400 });
  }

  try {
    const probe = await probeBybitDemo(apiKey, apiSecret);
    const positions = await fetchBybitPositions(apiKey, apiSecret);
    const exchangeUnrealized = positions.reduce(
      (sum, row) => sum + Number(row.unrealized_pnl ?? 0),
      0,
    );
    return NextResponse.json({
      ok: true,
      mode: "online",
      probe,
      exchange_positions: positions,
      exchange_stats: {
        unrealized_usd: Math.round(exchangeUnrealized * 100) / 100,
        position_count: positions.length,
      },
      updated_at: new Date().toISOString(),
    });
  } catch (e) {
    return NextResponse.json(
      { ok: false, error: e instanceof Error ? e.message : "Bybit request failed" },
      { status: 400 },
    );
  }
}
