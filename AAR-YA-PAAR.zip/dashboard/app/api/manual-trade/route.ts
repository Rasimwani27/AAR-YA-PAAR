import { NextResponse } from "next/server";

import { assertLocalEngine, repoRoot } from "@/lib/aar-paths";
import {
  bybitMarketClose,
  bybitMarketOpen,
  bybitUpdateStops,
  fetchBybitPositions,
} from "@/lib/bybit-orders";
import {
  closeManualPosition,
  computeManualTradeLegs,
  DEFAULT_MANUAL_PREFS,
  fetchBtcMarkPrice,
  getManualPosition,
  loadManualPrefs,
  mergeExchangeIntoState,
  openManualPosition,
  refreshForwardStateFile,
  resolveMarkPrice,
  saveManualPrefs,
  type ManualSizingMode,
  type ManualTradePrefs,
  updateManualPosition,
} from "@/lib/forward-ledger";
import { isHostedServer } from "@/lib/hosted-mode";
import type { ForwardSide } from "@/lib/forward-state";

export const runtime = "nodejs";

async function resolveMark(root: string, mark?: number, entryFallback?: number) {
  if (mark != null && mark > 0) return mark;
  if (entryFallback != null && entryFallback > 0) return entryFallback;
  try {
    return await fetchBtcMarkPrice();
  } catch {
    return resolveMarkPrice(root);
  }
}

export async function GET() {
  if (isHostedServer()) {
    return NextResponse.json({
      ok: true,
      hosted: true,
      prefs: DEFAULT_MANUAL_PREFS,
      message: "Manual paper trades save on your PC when you run the local dashboard.",
    });
  }
  const engineErr = assertLocalEngine(repoRoot());
  if (engineErr) {
    return NextResponse.json({ ok: false, error: engineErr }, { status: 503 });
  }
  const root = repoRoot();
  const prefs = loadManualPrefs(root);
  return NextResponse.json({ ok: true, prefs });
}

export async function POST(req: Request) {
  if (isHostedServer()) {
    return NextResponse.json(
      {
        ok: false,
        error: "Manual trades are local-only. Run START-HERE-43123.bat on your PC.",
      },
      { status: 503 },
    );
  }
  if (process.env.AAR_DISABLE_EXEC === "1") {
    return NextResponse.json({ ok: false, error: "Exec disabled" }, { status: 503 });
  }
  const root = repoRoot();
  const engineErr = assertLocalEngine(root);
  if (engineErr) {
    return NextResponse.json({ ok: false, error: engineErr }, { status: 503 });
  }

  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, error: "Invalid JSON" }, { status: 400 });
  }

  const action = String(body.action ?? "");

  try {
    if (action === "save_prefs") {
      const prefs: ManualTradePrefs = {
        account_equity_usd: Number(body.account_equity_usd ?? DEFAULT_MANUAL_PREFS.account_equity_usd),
        risk_pct_per_trade: Number(body.risk_pct_per_trade ?? DEFAULT_MANUAL_PREFS.risk_pct_per_trade),
        default_leverage: Number(body.default_leverage ?? DEFAULT_MANUAL_PREFS.default_leverage),
        default_stop_usd: Number(body.default_stop_usd ?? DEFAULT_MANUAL_PREFS.default_stop_usd),
        default_target_usd: Number(body.default_target_usd ?? DEFAULT_MANUAL_PREFS.default_target_usd),
        sizing_mode: (body.sizing_mode as ManualSizingMode) ?? DEFAULT_MANUAL_PREFS.sizing_mode,
        symbol: String(body.symbol ?? DEFAULT_MANUAL_PREFS.symbol),
        send_to_bybit_default: Boolean(
          body.send_to_bybit_default ?? DEFAULT_MANUAL_PREFS.send_to_bybit_default,
        ),
      };
      const saved = saveManualPrefs(root, prefs);
      return NextResponse.json({ ok: true, prefs: saved });
    }

    const entryFallback = body.entry_price != null ? Number(body.entry_price) : undefined;
    const apiKey = String(body.apiKey ?? "").trim();
    const apiSecret = String(body.apiSecret ?? "").trim();
    const prefs = loadManualPrefs(root);
    const wantBybit =
      Boolean(body.send_to_bybit ?? prefs.send_to_bybit_default) && apiKey.length > 0 && apiSecret.length > 0;

    const mark = await resolveMark(
      root,
      body.mark_price != null ? Number(body.mark_price) : undefined,
      entryFallback,
    );

    if (action === "refresh") {
      const out = refreshForwardStateFile(root, mark);
      return NextResponse.json({ ok: true, state: out.state, mark_price: mark });
    }

    if (action === "open") {
      const side = body.side as ForwardSide;
      if (side !== "long" && side !== "short") {
        return NextResponse.json({ ok: false, error: "side must be long or short" }, { status: 400 });
      }
      const openInput = {
        side,
        entry_price: entryFallback,
        stop_price: body.stop_price != null ? Number(body.stop_price) : undefined,
        target_price: body.target_price != null ? Number(body.target_price) : undefined,
        stop_usd: body.stop_usd != null ? Number(body.stop_usd) : undefined,
        target_usd: body.target_usd != null ? Number(body.target_usd) : undefined,
        qty: body.qty != null ? Number(body.qty) : undefined,
        notional_usd: body.notional_usd != null ? Number(body.notional_usd) : undefined,
        leverage: body.leverage != null ? Number(body.leverage) : undefined,
        risk_pct: body.risk_pct != null ? Number(body.risk_pct) : undefined,
        reason: body.reason != null ? String(body.reason) : undefined,
      };
      let bybitExtra: { bybit_order_id?: string; bybit_live?: boolean; entry_fill?: number } | undefined;
      if (wantBybit) {
        const legs = computeManualTradeLegs(root, openInput, mark);
        const placed = await bybitMarketOpen(apiKey, apiSecret, {
          symbol: legs.symbol,
          side: openInput.side,
          qty: legs.qty,
          stopPrice: legs.stopPrice,
          targetPrice: legs.targetPrice,
          leverage: legs.leverage,
        });
        bybitExtra = {
          bybit_order_id: placed.orderId,
          bybit_live: true,
          entry_fill: placed.avgPrice ?? legs.entry,
        };
      }
      const out = openManualPosition(root, openInput, mark, bybitExtra);
      let state = out.state;
      if (wantBybit) {
        const ex = await fetchBybitPositions(apiKey, apiSecret);
        state = mergeExchangeIntoState(state, ex);
      }
      return NextResponse.json({ ok: true, state, mark_price: mark, bybit_live: Boolean(bybitExtra?.bybit_live) });
    }

    if (action === "update") {
      const positionId = String(body.position_id ?? "");
      if (!positionId) {
        return NextResponse.json({ ok: false, error: "position_id required" }, { status: 400 });
      }
      const before = getManualPosition(root, positionId);
      const upd = {
        position_id: positionId,
        stop_price: body.stop_price != null ? Number(body.stop_price) : undefined,
        target_price: body.target_price != null ? Number(body.target_price) : undefined,
        qty: body.qty != null ? Number(body.qty) : undefined,
        leverage: body.leverage != null ? Number(body.leverage) : undefined,
        risk_pct: body.risk_pct != null ? Number(body.risk_pct) : undefined,
        reason: body.reason != null ? String(body.reason) : undefined,
      };
      if (wantBybit && before.bybit_live) {
        const prefsSym = loadManualPrefs(root).symbol;
        const stopP = upd.stop_price ?? before.stop_price;
        const targetP = upd.target_price ?? before.target_price;
        await bybitUpdateStops(apiKey, apiSecret, { symbol: prefsSym, stopPrice: stopP, targetPrice: targetP });
      }
      const out = updateManualPosition(root, upd, mark);
      let state = out.state;
      if (wantBybit) {
        state = mergeExchangeIntoState(state, await fetchBybitPositions(apiKey, apiSecret));
      }
      return NextResponse.json({ ok: true, state, mark_price: mark });
    }

    if (action === "close") {
      const positionId = String(body.position_id ?? "");
      if (!positionId) {
        return NextResponse.json({ ok: false, error: "position_id required" }, { status: 400 });
      }
      const before = getManualPosition(root, positionId);
      if (wantBybit && before.bybit_live) {
        await bybitMarketClose(apiKey, apiSecret, {
          symbol: loadManualPrefs(root).symbol,
          side: before.side,
          qty: before.qty,
        });
      }
      const out = closeManualPosition(
        root,
        positionId,
        mark,
        body.exit_price != null ? Number(body.exit_price) : undefined,
      );
      let state = out.state;
      if (wantBybit) {
        state = mergeExchangeIntoState(state, await fetchBybitPositions(apiKey, apiSecret));
      }
      return NextResponse.json({ ok: true, state, mark_price: mark });
    }

    return NextResponse.json({ ok: false, error: `Unknown action: ${action}` }, { status: 400 });
  } catch (e) {
    const msg = e instanceof Error ? e.message : "Manual trade failed";
    return NextResponse.json({ ok: false, error: msg }, { status: 400 });
  }
}
