import type { ForwardExchangePosition, ForwardState, ForwardStats } from "@/lib/forward-state";

export function sumExchangeUnrealized(exchange: ForwardExchangePosition[] | undefined): number {
  if (!exchange?.length) return 0;
  return exchange.reduce((sum, row) => {
    if (row.error) return sum;
    const v = Number(row.unrealized_pnl ?? 0);
    return sum + (Number.isFinite(v) ? v : 0);
  }, 0);
}

/** Paper stats from positions + history when Python/Node did not write `stats` yet. */
export function deriveForwardStats(state: ForwardState): ForwardStats {
  const positions = state.positions ?? [];
  const history = state.history ?? [];
  const unrealized = positions.reduce((s, p) => s + (p.unrealized_pnl_usd ?? 0), 0);
  const wins = history.filter((t) => t.gross_pnl_usd > 0).length;
  const losses = history.filter((t) => t.gross_pnl_usd < 0).length;
  const total = history.length;
  const net = history.reduce((s, t) => s + t.gross_pnl_usd, 0);
  const today = new Date().toISOString().slice(0, 10);
  const todayNet = history
    .filter((t) => t.closed_at.startsWith(today))
    .reduce((s, t) => s + t.gross_pnl_usd, 0);
  const byStrategy = new Map<
    string,
    { strategy_id: string; strategy_name: string; trades: number; wins: number; net_usd: number }
  >();
  for (const t of history) {
    const bucket =
      byStrategy.get(t.strategy_id) ??
      ({
        strategy_id: t.strategy_id,
        strategy_name: t.strategy_name,
        trades: 0,
        wins: 0,
        net_usd: 0,
      } as const);
    const next = {
      ...bucket,
      trades: bucket.trades + 1,
      wins: bucket.wins + (t.gross_pnl_usd > 0 ? 1 : 0),
      net_usd: Math.round((bucket.net_usd + t.gross_pnl_usd) * 100) / 100,
    };
    byStrategy.set(t.strategy_id, next);
  }
  return {
    open_count: positions.length,
    closed_trades: total,
    wins,
    losses,
    win_rate_pct: total ? Math.round((wins / total) * 1000) / 10 : 0,
    realized_pnl_usd: Math.round(net * 100) / 100,
    unrealized_pnl_usd: Math.round(unrealized * 100) / 100,
    total_pnl_usd: Math.round((net + unrealized) * 100) / 100,
    today_realized_usd: Math.round(todayNet * 100) / 100,
    by_strategy: [...byStrategy.values()],
  };
}

export function resolveForwardStats(state: ForwardState | null | undefined): ForwardStats | null {
  if (!state) return null;
  if (state.stats) return state.stats;
  if ((state.positions?.length ?? 0) > 0 || (state.history?.length ?? 0) > 0) {
    return deriveForwardStats(state);
  }
  const exchangeUpnl = sumExchangeUnrealized(state.exchange_positions);
  if (exchangeUpnl !== 0 || (state.exchange_positions?.length ?? 0) > 0) {
    return {
      open_count: state.exchange_stats?.position_count ?? state.exchange_positions?.length ?? 0,
      closed_trades: 0,
      wins: 0,
      losses: 0,
      win_rate_pct: 0,
      realized_pnl_usd: 0,
      unrealized_pnl_usd: exchangeUpnl,
      total_pnl_usd: exchangeUpnl,
      today_realized_usd: 0,
      by_strategy: [],
    };
  }
  return {
    open_count: 0,
    closed_trades: 0,
    wins: 0,
    losses: 0,
    win_rate_pct: 0,
    realized_pnl_usd: 0,
    unrealized_pnl_usd: 0,
    total_pnl_usd: 0,
    today_realized_usd: 0,
    by_strategy: [],
  };
}
