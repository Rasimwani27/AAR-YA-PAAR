/**
 * Bybit demo trading — place/amend/close linear orders (signed POST v5).
 */

import { createHmac } from "node:crypto";

import { formatBybitReachabilityError } from "@/lib/bybit-probe";

const DEMO_BASE = "https://api-demo.bybit.com";
const RECV_WINDOW = "50000";

function signV5(timestamp: string, apiKey: string, recvWindow: string, payload: string, secret: string): string {
  const raw = `${timestamp}${apiKey}${recvWindow}${payload}`;
  return createHmac("sha256", secret).update(raw).digest("hex");
}

function sortedQs(params: Record<string, string>): string {
  return Object.keys(params)
    .sort()
    .map((k) => `${encodeURIComponent(k)}=${encodeURIComponent(params[k] ?? "")}`)
    .join("&");
}

async function requestSignedGet(
  path: string,
  params: Record<string, string>,
  apiKey: string,
  apiSecret: string,
): Promise<Record<string, unknown>> {
  const qs = sortedQs(params);
  const ts = String(Date.now());
  const sign = signV5(ts, apiKey, RECV_WINDOW, qs, apiSecret);
  const res = await fetch(`${DEMO_BASE}${path}?${qs}`, {
    method: "GET",
    headers: {
      Accept: "application/json",
      "User-Agent": "aar-dashboard/1.0",
      "X-BAPI-API-KEY": apiKey,
      "X-BAPI-SIGN": sign,
      "X-BAPI-SIGN-TYPE": "2",
      "X-BAPI-TIMESTAMP": ts,
      "X-BAPI-RECV-WINDOW": RECV_WINDOW,
    },
  });
  const text = await res.text();
  let data: Record<string, unknown>;
  try {
    data = text ? (JSON.parse(text) as Record<string, unknown>) : {};
  } catch {
    throw new Error(formatBybitReachabilityError(res.status, text));
  }
  if (!res.ok) throw new Error(formatBybitReachabilityError(res.status, text));
  const rc = data.retCode;
  if (rc != null && rc !== 0 && rc !== "0") throw new Error(`Bybit ${path}: ${text}`);
  return data;
}

export async function fetchBybitPositions(apiKey: string, apiSecret: string) {
  const data = await requestSignedGet(
    "/v5/position/list",
    { category: "linear", settleCoin: "USDT" },
    apiKey,
    apiSecret,
  );
  const list = (data.result as { list?: unknown[] } | undefined)?.list ?? [];
  const out: Array<Record<string, unknown>> = [];
  for (const row of list) {
    if (!row || typeof row !== "object") continue;
    const r = row as Record<string, unknown>;
    const sz = parseFloat(String(r.size ?? 0));
    if (Math.abs(sz) < 1e-12) continue;
    out.push({
      symbol: r.symbol,
      side: String(r.side) === "Buy" ? "long" : "short",
      qty: Math.abs(sz),
      entry_price: parseFloat(String(r.avgPrice ?? 0)),
      mark_price: parseFloat(String(r.markPrice ?? r.lastPrice ?? 0)),
      unrealized_pnl: parseFloat(String(r.unrealisedPnl ?? r.unrealizedPnl ?? 0)),
      leverage: r.leverage,
    });
  }
  return out;
}

async function requestSignedPost(
  path: string,
  body: Record<string, unknown>,
  apiKey: string,
  apiSecret: string,
): Promise<Record<string, unknown>> {
  const jsonBody = JSON.stringify(body);
  const ts = String(Date.now());
  const sign = signV5(ts, apiKey, RECV_WINDOW, jsonBody, apiSecret);
  const res = await fetch(`${DEMO_BASE}${path}`, {
    method: "POST",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      "User-Agent": "aar-dashboard/1.0",
      "X-BAPI-API-KEY": apiKey,
      "X-BAPI-SIGN": sign,
      "X-BAPI-SIGN-TYPE": "2",
      "X-BAPI-TIMESTAMP": ts,
      "X-BAPI-RECV-WINDOW": RECV_WINDOW,
    },
    body: jsonBody,
  });
  const text = await res.text();
  let data: Record<string, unknown>;
  try {
    data = text ? (JSON.parse(text) as Record<string, unknown>) : {};
  } catch {
    throw new Error(formatBybitReachabilityError(res.status, text));
  }
  if (!res.ok) {
    throw new Error(formatBybitReachabilityError(res.status, text));
  }
  const rc = data.retCode;
  if (rc != null && rc !== 0 && rc !== "0") {
    throw new Error(`Bybit ${path}: ${text}`);
  }
  return data;
}

export function formatBybitQty(qty: number): string {
  const steps = Math.floor(qty * 1000) / 1000;
  if (steps < 0.001) {
    throw new Error("Qty too small for BTCUSDT (min 0.001)");
  }
  return steps.toFixed(3);
}

export async function setBybitLeverage(
  apiKey: string,
  apiSecret: string,
  symbol: string,
  leverage: number,
): Promise<void> {
  const lev = String(Math.min(100, Math.max(1, Math.round(leverage))));
  try {
    await requestSignedPost(
      "/v5/position/set-leverage",
      {
        category: "linear",
        symbol,
        buyLeverage: lev,
        sellLeverage: lev,
      },
      apiKey,
      apiSecret,
    );
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    if (/same|not modified|110043/i.test(msg)) return;
    throw e;
  }
}

export type BybitMarketOpenResult = {
  orderId: string;
  avgPrice: number | null;
};

export async function bybitMarketOpen(
  apiKey: string,
  apiSecret: string,
  params: {
    symbol: string;
    side: "long" | "short";
    qty: number;
    stopPrice: number;
    targetPrice: number;
    leverage: number;
  },
): Promise<BybitMarketOpenResult> {
  await setBybitLeverage(apiKey, apiSecret, params.symbol, params.leverage);
  const side = params.side === "long" ? "Buy" : "Sell";
  const data = await requestSignedPost(
    "/v5/order/create",
    {
      category: "linear",
      symbol: params.symbol,
      side,
      orderType: "Market",
      qty: formatBybitQty(params.qty),
      positionIdx: 0,
      stopLoss: String(params.stopPrice),
      takeProfit: String(params.targetPrice),
      tpTriggerBy: "MarkPrice",
      slTriggerBy: "MarkPrice",
      tpslMode: "Full",
    },
    apiKey,
    apiSecret,
  );
  const result = data.result as Record<string, unknown> | undefined;
  const orderId = String(result?.orderId ?? "");
  let avgPrice: number | null = null;
  if (result?.avgPrice != null) {
    avgPrice = parseFloat(String(result.avgPrice));
  }
  return { orderId, avgPrice };
}

export async function bybitMarketClose(
  apiKey: string,
  apiSecret: string,
  params: { symbol: string; side: "long" | "short"; qty: number },
): Promise<void> {
  const closeSide = params.side === "long" ? "Sell" : "Buy";
  await requestSignedPost(
    "/v5/order/create",
    {
      category: "linear",
      symbol: params.symbol,
      side: closeSide,
      orderType: "Market",
      qty: formatBybitQty(params.qty),
      positionIdx: 0,
      reduceOnly: true,
    },
    apiKey,
    apiSecret,
  );
}

export async function bybitUpdateStops(
  apiKey: string,
  apiSecret: string,
  params: { symbol: string; stopPrice: number; targetPrice: number },
): Promise<void> {
  await requestSignedPost(
    "/v5/position/trading-stop",
    {
      category: "linear",
      symbol: params.symbol,
      positionIdx: 0,
      stopLoss: String(params.stopPrice),
      takeProfit: String(params.targetPrice),
      tpTriggerBy: "MarkPrice",
      slTriggerBy: "MarkPrice",
    },
    apiKey,
    apiSecret,
  );
}
