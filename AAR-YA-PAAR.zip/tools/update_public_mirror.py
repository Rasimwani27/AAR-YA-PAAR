#!/usr/bin/env python3
"""Upload AAR-YA-PAAR.zip to tmpfiles and write direct download URL (not the HTML page)."""

from __future__ import annotations

import json
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    subprocess.run([sys.executable, str(ROOT / "tools" / "pack_download_zip.py")], check=True, cwd=ROOT)
    zip_path = ROOT / "dashboard" / "public" / "AAR-YA-PAAR.zip"
    import urllib.request

    boundary = "----AARBoundary"
    data = (
        f"--{boundary}\r\n"
        f'Content-Disposition: form-data; name="file"; filename="AAR-YA-PAAR.zip"\r\n'
        f"Content-Type: application/zip\r\n\r\n"
    ).encode()
    data += zip_path.read_bytes()
    data += f"\r\n--{boundary}--\r\n".encode()
    req = urllib.request.Request(
        "https://tmpfiles.org/api/v1/upload",
        data=data,
        headers={"Content-Type": f"multipart/form-data; boundary={boundary}"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=120) as resp:
        meta = json.loads(resp.read().decode())
    page_url = meta["data"]["url"]
    page = urllib.request.urlopen(page_url, timeout=60).read().decode("utf-8", errors="replace")
    m = re.search(r'href="(https://tmpfiles\.org/dl/[^"]+aar-ya-paar\.zip)"', page, re.I)
    if not m:
        raise SystemExit(f"Could not find direct dl link on {page_url}")
    direct = m.group(1)
    size = zip_path.stat().st_size
    payload = {
        "zipName": "AAR-YA-PAAR.zip",
        "bytes": size,
        "mirrorPageUrl": page_url,
        "directDownloadUrl": direct,
        "note": "Use directDownloadUrl — saves the real zip (~498 KB). After save, unzip and run START-HERE-43123.bat",
        "labBuild": "2026.11.11-manual-trade",
    }
    out = ROOT / "dashboard" / "public" / "download-link.json"
    out.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    (ROOT / "PUBLIC-DOWNLOAD-LINK.txt").write_text(
        f"Direct zip (click or right-click Save link as):\n\n{direct}\n\n"
        f"Size: {size} bytes. Must contain START-HERE-43123.bat after extract.\n",
        encoding="utf-8",
    )
    print(direct)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
